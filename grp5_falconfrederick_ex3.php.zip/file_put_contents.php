<?php
echo file_put_contents('file_put_contents_sample.txt', 'THIS IS A SAMPLE!');
?>